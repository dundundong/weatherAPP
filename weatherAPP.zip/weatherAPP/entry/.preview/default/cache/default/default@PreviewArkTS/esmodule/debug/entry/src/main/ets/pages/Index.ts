if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    cityWeatherList?: Array<WeatherModel>;
    cityCodeList?: Array<number>;
    cityNameList?: Array<string>;
    cityIndex?: number;
    tabController?: TabsController;
}
import { cityView } from "@normalized:N&&&entry/src/main/ets/view/cityView&";
import getWeatherUtil from "@normalized:N&&&entry/src/main/ets/viewmodel/getWeatherUtil&";
import { WeatherModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/WeatherModel&";
import router from "@ohos:router";
interface GeneratedTypeLiteralInterface_1 {
    codes?: number[]; // 明确指定参数类型
    names?: string[];
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__cityWeatherList = new ObservedPropertyObjectPU([]
        //当前城市代码列表
        , this, "cityWeatherList");
        this.__cityCodeList = new ObservedPropertyObjectPU([110000, 120000]
        //城市名字集合
        , this, "cityCodeList");
        this.__cityNameList = new ObservedPropertyObjectPU([]
        //当前城市索引
        , this, "cityNameList");
        this.__cityIndex = new ObservedPropertySimplePU(0, this, "cityIndex");
        this.tabController = new TabsController();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.cityWeatherList !== undefined) {
            this.cityWeatherList = params.cityWeatherList;
        }
        if (params.cityCodeList !== undefined) {
            this.cityCodeList = params.cityCodeList;
        }
        if (params.cityNameList !== undefined) {
            this.cityNameList = params.cityNameList;
        }
        if (params.cityIndex !== undefined) {
            this.cityIndex = params.cityIndex;
        }
        if (params.tabController !== undefined) {
            this.tabController = params.tabController;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__cityWeatherList.purgeDependencyOnElmtId(rmElmtId);
        this.__cityCodeList.purgeDependencyOnElmtId(rmElmtId);
        this.__cityNameList.purgeDependencyOnElmtId(rmElmtId);
        this.__cityIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__cityWeatherList.aboutToBeDeleted();
        this.__cityCodeList.aboutToBeDeleted();
        this.__cityNameList.aboutToBeDeleted();
        this.__cityIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //城市信息集合
    private __cityWeatherList: ObservedPropertyObjectPU<Array<WeatherModel>>;
    get cityWeatherList() {
        return this.__cityWeatherList.get();
    }
    set cityWeatherList(newValue: Array<WeatherModel>) {
        this.__cityWeatherList.set(newValue);
    }
    //当前城市代码列表
    private __cityCodeList: ObservedPropertyObjectPU<Array<number>>;
    get cityCodeList() {
        return this.__cityCodeList.get();
    }
    set cityCodeList(newValue: Array<number>) {
        this.__cityCodeList.set(newValue);
    }
    //城市名字集合
    private __cityNameList: ObservedPropertyObjectPU<Array<string>>;
    get cityNameList() {
        return this.__cityNameList.get();
    }
    set cityNameList(newValue: Array<string>) {
        this.__cityNameList.set(newValue);
    }
    //当前城市索引
    private __cityIndex: ObservedPropertySimplePU<number>;
    get cityIndex() {
        return this.__cityIndex.get();
    }
    set cityIndex(newValue: number) {
        this.__cityIndex.set(newValue);
    }
    private tabController: TabsController;
    //按钮样式
    tabBuild(index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create({ width: 10, height: 10 });
            Circle.debugLine("entry/src/main/ets/pages/Index.ets(28:5)", "entry");
            Circle.fill(this.cityIndex === index ? Color.White : Color.Gray);
            Circle.opacity(0.4);
        }, Circle);
    }
    onPageShow(): void {
        let params = router.getParams() as GeneratedTypeLiteralInterface_1;
        if (params !== null) {
            this.cityCodeList = params?.codes || [];
            //清空所有数据
            this.cityWeatherList = [];
            this.cityNameList = [];
            this.initData();
        }
    }
    //获取资源
    aboutToAppear() {
        this.initData();
    }
    async initData() {
        //所有数据的集合
        let result: Array<WeatherModel> = await getWeatherUtil.getWeathers(this.cityCodeList);
        for (let i = 0; i < result.length; i++) {
            let ACityWeather = new WeatherModel();
            ACityWeather = result[i];
            this.cityWeatherList.push(ACityWeather);
            let cityName = this.cityWeatherList[i].forecasts[0].city;
            this.cityNameList.push(cityName);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(68:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor("#87CEEB");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(69:7)", "entry");
            Row.width("100%");
            Row.height("10%");
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("添加");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(70:9)", "entry");
            Button.fontSize(25);
            Button.fontColor(Color.Gray);
            Button.opacity(0.7);
            Button.backgroundColor("#87CEEB");
            Button.margin({ bottom: 15 });
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/AddCity",
                    params: {
                        codes: this.cityCodeList,
                        names: this.cityNameList
                    }
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.cityNameList[this.cityIndex]);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(86:9)", "entry");
            Text.fontSize(40);
            Text.fontColor(Color.Orange);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("删除");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(87:9)", "entry");
            Button.fontSize(25);
            Button.fontColor(Color.Gray);
            Button.opacity(0.7);
            Button.backgroundColor("#87CEEB");
            Button.margin({ bottom: 15 });
            Button.onClick(() => {
                AlertDialog.show({
                    title: "删除",
                    message: `你确定要删除${this.cityNameList[this.cityIndex]}吗`,
                    confirm: {
                        value: "确定",
                        action: () => {
                            this.cityNameList =
                                this.cityNameList.filter(item => item !== this.cityNameList[this.cityIndex]);
                            this.cityCodeList =
                                this.cityCodeList.filter(item => item !== this.cityCodeList[this.cityIndex]);
                            this.cityWeatherList =
                                this.cityWeatherList.filter(item => item !== this.cityWeatherList[this.cityIndex]);
                        }
                    }
                });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ barPosition: BarPosition.Start, controller: this.tabController });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(113:7)", "entry");
            Tabs.barWidth(40);
            Tabs.barHeight(40);
            Tabs.onChange((index: number) => {
                this.cityIndex = index;
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const cityWeather = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    TabContent.create(() => {
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new cityView(this, { casts: cityWeather.forecasts[0].casts }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 116, col: 13 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            casts: cityWeather.forecasts[0].casts
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                            }, { name: "cityView" });
                        }
                    });
                    TabContent.tabBar({ builder: () => {
                            this.tabBuild.call(this, this.cityWeatherList.findIndex(obj => obj === cityWeather));
                        } });
                    TabContent.debugLine("entry/src/main/ets/pages/Index.ets(115:11)", "entry");
                }, TabContent);
                TabContent.pop();
            };
            this.forEachUpdateFunction(elmtId, this.cityWeatherList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        Tabs.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.weatherapp", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
