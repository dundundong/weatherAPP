import type { Forecasts } from "./forecasts";
export class WeatherModel {
    status: string = ''; // API返回的是字符串
    count: string = ''; // API返回的是字符串
    info: string = '';
    infocode: string = ''; // API返回的是字符串
    forecasts: Array<Forecasts> = [];
}
