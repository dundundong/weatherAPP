if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AddCity_Params {
    AllCityCodeList?: Array<number>;
    AllCityNameList?: Array<string>;
    cityCodeList?: number[];
    cityNameList?: string[];
}
import router from "@ohos:router";
interface GeneratedTypeLiteralInterface_1 {
    codes?: number[]; // 明确指定参数类型
    names?: string[];
}
class AddCity extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__AllCityCodeList = new ObservedPropertyObjectPU([110000, 120000, 130000, 140000, 210000, 220000, 310000], this, "AllCityCodeList");
        this.__AllCityNameList = new ObservedPropertyObjectPU(["北京市", "天津市", "河北省", "山西省", "辽宁省", "吉林省", "上海市"]
        //接收数据的载体
        , this, "AllCityNameList");
        this.__cityCodeList = new ObservedPropertyObjectPU([], this, "cityCodeList");
        this.__cityNameList = new ObservedPropertyObjectPU([], this, "cityNameList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AddCity_Params) {
        if (params.AllCityCodeList !== undefined) {
            this.AllCityCodeList = params.AllCityCodeList;
        }
        if (params.AllCityNameList !== undefined) {
            this.AllCityNameList = params.AllCityNameList;
        }
        if (params.cityCodeList !== undefined) {
            this.cityCodeList = params.cityCodeList;
        }
        if (params.cityNameList !== undefined) {
            this.cityNameList = params.cityNameList;
        }
    }
    updateStateVars(params: AddCity_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__AllCityCodeList.purgeDependencyOnElmtId(rmElmtId);
        this.__AllCityNameList.purgeDependencyOnElmtId(rmElmtId);
        this.__cityCodeList.purgeDependencyOnElmtId(rmElmtId);
        this.__cityNameList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__AllCityCodeList.aboutToBeDeleted();
        this.__AllCityNameList.aboutToBeDeleted();
        this.__cityCodeList.aboutToBeDeleted();
        this.__cityNameList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __AllCityCodeList: ObservedPropertyObjectPU<Array<number>>;
    get AllCityCodeList() {
        return this.__AllCityCodeList.get();
    }
    set AllCityCodeList(newValue: Array<number>) {
        this.__AllCityCodeList.set(newValue);
    }
    private __AllCityNameList: ObservedPropertyObjectPU<Array<string>>;
    get AllCityNameList() {
        return this.__AllCityNameList.get();
    }
    set AllCityNameList(newValue: Array<string>) {
        this.__AllCityNameList.set(newValue);
    }
    //接收数据的载体
    private __cityCodeList: ObservedPropertyObjectPU<number[]>;
    get cityCodeList() {
        return this.__cityCodeList.get();
    }
    set cityCodeList(newValue: number[]) {
        this.__cityCodeList.set(newValue);
    }
    private __cityNameList: ObservedPropertyObjectPU<string[]>;
    get cityNameList() {
        return this.__cityNameList.get();
    }
    set cityNameList(newValue: string[]) {
        this.__cityNameList.set(newValue);
    }
    onPageShow(): void {
        let params = router.getParams() as GeneratedTypeLiteralInterface_1;
        // 使用可选链和类型安全的访问方式
        this.cityCodeList = params?.codes || [];
        this.cityNameList = params?.names || [];
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCity.ets(30:5)", "entry");
            Column.width("100%");
            Column.height("100%");
            Column.backgroundColor("#87CEEB");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCity.ets(31:7)", "entry");
            Row.height("10%");
            Row.width("95%");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("添加城市列表");
            Text.debugLine("entry/src/main/ets/pages/AddCity.ets(32:9)", "entry");
            Text.fontSize(35);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCity.ets(33:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("完成");
            Button.debugLine("entry/src/main/ets/pages/AddCity.ets(34:9)", "entry");
            Button.fontSize(26);
            Button.backgroundColor("");
            Button.onClick(() => {
                router.back({
                    url: "pages/Index",
                    params: {
                        codes: this.cityCodeList,
                        name: this.cityNameList
                    }
                });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCity.ets(46:7)", "entry");
            Column.width("100%");
            Column.height("90%");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/pages/AddCity.ets(47:9)", "entry");
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const name = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/AddCity.ets(49:13)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (this.cityNameList.includes(name)) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/AddCity.ets(51:17)", "entry");
                                        Column.height(90);
                                        Column.width("100%");
                                        Column.margin({ top: 20 });
                                        Column.backgroundColor("#4682b4");
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/AddCity.ets(52:19)", "entry");
                                        Row.width("100%");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(name);
                                        Text.debugLine("entry/src/main/ets/pages/AddCity.ets(53:21)", "entry");
                                        Text.fontSize(35);
                                        Text.fontColor(Color.White);
                                        Text.width("60%");
                                        Text.margin({ top: 20, left: 30 });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/AddCity.ets(55:21)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create("已添加");
                                        Text.debugLine("entry/src/main/ets/pages/AddCity.ets(56:21)", "entry");
                                        Text.backgroundColor("");
                                        Text.fontSize(18);
                                        Text.margin({ top: 5 });
                                        Text.opacity(0.8);
                                    }, Text);
                                    Text.pop();
                                    Row.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/AddCity.ets(59:19)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Divider.create();
                                        Divider.debugLine("entry/src/main/ets/pages/AddCity.ets(60:19)", "entry");
                                        Divider.strokeWidth(5);
                                    }, Divider);
                                    Column.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/AddCity.ets(64:17)", "entry");
                                        Column.height(90);
                                        Column.width("100%");
                                        Column.margin({ top: 20 });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/AddCity.ets(65:19)", "entry");
                                        Row.width("100%");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(name);
                                        Text.debugLine("entry/src/main/ets/pages/AddCity.ets(66:21)", "entry");
                                        Text.fontSize(35);
                                        Text.fontColor(Color.White);
                                        Text.width("60%");
                                        Text.margin({ top: 20, left: 30 });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Button.createWithLabel("添加");
                                        Button.debugLine("entry/src/main/ets/pages/AddCity.ets(68:21)", "entry");
                                        Button.backgroundColor("");
                                        Button.fontSize(18);
                                        Button.margin({ right: 5 });
                                        Button.onClick(() => {
                                            //根据name 获取所在索引
                                            let index = this.AllCityNameList.findIndex(obj => obj === name);
                                            //根据获得的索引来获取城市的对应代码
                                            let cityCode: number = this.AllCityCodeList[index];
                                            //将编码加入列表
                                            this.cityCodeList.push(cityCode);
                                            this.cityNameList.push(name);
                                        });
                                    }, Button);
                                    Button.pop();
                                    Row.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/AddCity.ets(82:19)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Divider.create();
                                        Divider.debugLine("entry/src/main/ets/pages/AddCity.ets(83:19)", "entry");
                                        Divider.strokeWidth(5);
                                    }, Divider);
                                    Column.pop();
                                });
                            }
                        }, If);
                        If.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.AllCityNameList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "AddCity";
    }
}
registerNamedRoute(() => new AddCity(undefined, {}), "", { bundleName: "com.example.weatherapp", moduleName: "entry", pagePath: "pages/AddCity", pageFullPath: "entry/src/main/ets/pages/AddCity", integratedHsp: "false", moduleType: "followWithHap" });
