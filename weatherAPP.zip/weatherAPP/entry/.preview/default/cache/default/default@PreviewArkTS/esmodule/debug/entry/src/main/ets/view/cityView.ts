if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface cityView_Params {
    //获取数据
    //城市天气数据
    casts?: Array<Casts>;
}
import type { Casts } from "../viewmodel/casts";
export class cityView extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.casts = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: cityView_Params) {
        if (params.casts !== undefined) {
            this.casts = params.casts;
        }
    }
    updateStateVars(params: cityView_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //获取数据
    //城市天气数据
    private casts: Array<Casts>;
    weartherImage(weather: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (weather === "晴") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/view/cityView.ets(14:9)", "entry");
                        Image.width(30);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (weather === "阴") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/view/cityView.ets(17:9)", "entry");
                        Image.width(30);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (weather === "多云") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/view/cityView.ets(20:9)", "entry");
                        Image.width(30);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (weather === "雨") {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/view/cityView.ets(23:9)", "entry");
                        Image.width(30);
                    }, Image);
                });
            }
            else //展示数据
             {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
    }
    //展示数据
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/cityView.ets(29:5)", "entry");
            Column.width("100%");
            Column.height("100%");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //当天天气数据
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const cast = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.casts[0] === cast) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                //图片
                                Row.create();
                                Row.debugLine("entry/src/main/ets/view/cityView.ets(34:11)", "entry");
                                //图片
                                Row.height("30%");
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (cast.dayweather === "晴") {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                                            Image.debugLine("entry/src/main/ets/view/cityView.ets(36:15)", "entry");
                                            Image.width(260);
                                        }, Image);
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (cast.dayweather === "阴") {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                                            Image.debugLine("entry/src/main/ets/view/cityView.ets(39:15)", "entry");
                                            Image.width(260);
                                        }, Image);
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (cast.dayweather === "多云") {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                                            Image.debugLine("entry/src/main/ets/view/cityView.ets(42:15)", "entry");
                                            Image.width(260);
                                        }, Image);
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (cast.dayweather === "雨") {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.weatherapp", "moduleName": "entry" });
                                            Image.debugLine("entry/src/main/ets/view/cityView.ets(45:15)", "entry");
                                            Image.width(260);
                                        }, Image);
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            //图片
                            Row.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/view/cityView.ets(48:11)", "entry");
                                Column.margin({ top: 10 });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                //温度 天气
                                Row.create();
                                Row.debugLine("entry/src/main/ets/view/cityView.ets(50:13)", "entry");
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(cast.dayweather);
                                Text.debugLine("entry/src/main/ets/view/cityView.ets(51:15)", "entry");
                                Text.fontSize(30);
                                Text.fontColor(Color.White);
                                Text.fontWeight(FontWeight.Bold);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(" " + cast.daytemp + "° ~" + cast.nighttemp + "°");
                                Text.debugLine("entry/src/main/ets/view/cityView.ets(53:15)", "entry");
                                Text.fontSize(30);
                                Text.fontColor(Color.White);
                                Text.fontWeight(FontWeight.Bold);
                            }, Text);
                            Text.pop();
                            //温度 天气
                            Row.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/view/cityView.ets(56:13)", "entry");
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(cast.daywind + "风");
                                Text.debugLine("entry/src/main/ets/view/cityView.ets(57:15)", "entry");
                                Text.fontSize(30);
                                Text.fontColor(Color.White);
                                Text.fontWeight(FontWeight.Bold);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(cast.daypower + "级");
                                Text.debugLine("entry/src/main/ets/view/cityView.ets(59:15)", "entry");
                                Text.fontSize(30);
                                Text.fontColor(Color.White);
                                Text.fontWeight(FontWeight.Bold);
                            }, Text);
                            Text.pop();
                            Row.pop();
                            Column.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
            };
            this.forEachUpdateFunction(elmtId, this.casts, forEachItemGenFunction);
        }, ForEach);
        //当天天气数据
        ForEach.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //近期天气数据
            Column.create();
            Column.debugLine("entry/src/main/ets/view/cityView.ets(68:7)", "entry");
            //近期天气数据
            Column.width("100%");
            //近期天气数据
            Column.height("45%");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("近期天气查询");
            Text.debugLine("entry/src/main/ets/view/cityView.ets(69:9)", "entry");
            Text.fontSize(26);
            Text.margin({ top: 30 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //近期天气列表
            Row.create();
            Row.debugLine("entry/src/main/ets/view/cityView.ets(71:9)", "entry");
            //近期天气列表
            Row.width("88%");
            //近期天气列表
            Row.height("60%");
            //近期天气列表
            Row.backgroundColor("#ffbab8b8");
            //近期天气列表
            Row.opacity(0.5);
            //近期天气列表
            Row.justifyContent(FlexAlign.SpaceAround);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const cast = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/view/cityView.ets(73:13)", "entry");
                    Column.width("20%");
                    Column.height("90%");
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(cast.date.substring(5));
                    Text.debugLine("entry/src/main/ets/view/cityView.ets(74:15)", "entry");
                }, Text);
                Text.pop();
                this.weartherImage.bind(this)(cast.dayweather);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(cast.daytemp.toString());
                    Text.debugLine("entry/src/main/ets/view/cityView.ets(76:15)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Line.create();
                    Line.debugLine("entry/src/main/ets/view/cityView.ets(77:15)", "entry");
                    Line.width(20);
                    Line.height(80);
                    Line.startPoint([10, 0]);
                    Line.endPoint([10, 70]);
                    Line.stroke(Color.Black);
                    Line.strokeWidth(3);
                    Line.strokeDashArray([10, 3]);
                }, Line);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(cast.nighttemp.toString());
                    Text.debugLine("entry/src/main/ets/view/cityView.ets(81:15)", "entry");
                }, Text);
                Text.pop();
                this.weartherImage.bind(this)(cast.nightweather);
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.casts, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        //近期天气列表
        Row.pop();
        //近期天气数据
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
