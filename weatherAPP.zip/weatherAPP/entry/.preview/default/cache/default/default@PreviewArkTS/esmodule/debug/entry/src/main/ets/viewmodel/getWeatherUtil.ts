import type { WeatherModel } from "../viewmodel/WeatherModel";
import http from "@ohos:net.http";
class GetWeatherUtil {
    getWeather(cityCode: number): Promise<WeatherModel> {
        return new Promise<WeatherModel>((resolve, reject) => {
            let request = http.createHttp();
            let url = `https://restapi.amap.com/v3/weather/weatherInfo?city=${cityCode}&key=f7ac7d705fbe7dee7af56aec3dd12214&extensions=all`;
            console.log("请求URL:", url);
            request.request(url, (err, res) => {
                if (err) {
                    console.error("请求错误:", err); // 添加错误日志
                    reject(err);
                    return;
                }
                console.log("响应状态码:", res.responseCode); // 添加响应日志
                console.log("响应数据:", res.result.toString()); // 添加这行查看原始响应
                if (res.responseCode === 200) {
                    try {
                        const weatherData: WeatherModel = JSON.parse(res.result.toString());
                        console.log("天气数据:", weatherData); // 添加成功日志
                        resolve(weatherData);
                    }
                    catch (e) {
                        console.error("解析错误:", e); // 添加解析错误日志
                        reject(new Error('Failed to parse weather data'));
                    }
                }
                else {
                    console.error("请求失败:", res.responseCode); // 添加失败日志
                    reject(new Error(`Request failed with status code ${res.responseCode}`));
                }
            });
        });
    }
    //直接发送多个url，结果一并返回
    async getWeathers(cityCodes: Array<number>): Promise<WeatherModel[]> {
        const promises: Array<Promise<WeatherModel>> = [];
        for (let i = 0; i < cityCodes.length; i++) {
            promises.push(this.getWeather(cityCodes[i]));
        }
        return Promise.all(promises).then(results => {
            results.forEach(element => {
                if (element.forecasts && element.forecasts.length > 0) {
                    console.log(element.forecasts[0].city);
                }
            });
            return results; // 明确返回WeatherModel数组
        });
    }
}
const getWeatherUtil = new GetWeatherUtil();
export default getWeatherUtil;
